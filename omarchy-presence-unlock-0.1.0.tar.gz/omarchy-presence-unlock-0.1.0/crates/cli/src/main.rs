mod atomic;
mod client;
mod devices;
mod doctor;
mod enrollment;
mod interrupt;
mod keys;
mod pairing;
mod setup;
mod ui;
mod wizard;

use clap::{CommandFactory, Parser, Subcommand};
use devices::{Criteria, Overrides};
use omarchy_presence_unlock_protocol::wire;
use std::io::IsTerminal;
use std::time::Duration;

#[derive(Parser)]
#[command(about = "BLE proximity unlock for Omarchy")]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand)]
enum Commands {
    /// Enroll an Apple Watch from a macOS Remote IRK, read without echoing it.
    /// Use `enroll-device --provider apple-watch` for Linux-side enrollment.
    Enroll {
        /// Device id used in status output. Defaults to `watch`.
        #[arg(long, default_value = "watch")]
        id: String,
    },
    /// Enroll any BLE device by address, service UUID, or advertised name.
    #[command(allow_negative_numbers = true)]
    AddDevice {
        /// Device id used in status output.
        id: String,
        /// Built-in profile id, for example `presence` or `apple-continuity`.
        #[arg(long, default_value = "presence")]
        profile: String,
        /// Fixed address, as shown by `devices`. Useless for a device that
        /// rotates private addresses; use --irk for those.
        #[arg(long)]
        address: Option<String>,
        /// Base64 IRK, for a device that rotates resolvable private addresses.
        #[arg(long)]
        irk: Option<String>,
        /// Match any device advertising this service UUID.
        #[arg(long)]
        service_uuid: Option<String>,
        /// Match devices whose advertised name starts with this prefix.
        #[arg(long)]
        name_prefix: Option<String>,
        /// RSSI at or above which this device counts as near.
        #[arg(long)]
        threshold_dbm: Option<i16>,
        /// Qualifying advertisements required before this device is eligible.
        #[arg(long)]
        minimum_samples: Option<u8>,
        /// How long a qualifying advertisement stays valid.
        #[arg(long)]
        freshness_ms: Option<u64>,
    },
    /// Remove an enrolled device.
    RemoveDevice { id: String },
    /// Choose how many enrolled devices must authorize an unlock: any, all, or at-least:<n>.
    MultiDeviceAuth { expression: String },
    /// Scan for advertising BLE devices (live, not the `BlueZ` cache).
    Devices {
        /// Bluetooth adapter name. Uses the `BlueZ` default adapter when omitted.
        #[arg(long)]
        adapter: Option<String>,
        /// Seconds to scan before showing the list.
        #[arg(long, default_value_t = 12)]
        scan_secs: u64,
    },
    /// Proof of concept: scan, pick a device, pair it, and read the IRK `BlueZ` stored.
    /// Experimental — Apple Watch bonding to a Linux central is unproven.
    Pair {
        /// Bluetooth adapter name. Uses the `BlueZ` default adapter when omitted.
        #[arg(long)]
        adapter: Option<String>,
        /// Seconds to scan before showing the list.
        #[arg(long, default_value_t = 12)]
        scan_secs: u64,
        /// Device id to write when --save is given.
        #[arg(long, default_value = "watch")]
        id: String,
        /// Save the extracted IRK as an apple-watch enrollment. Off by default:
        /// without it the command only reports whether an IRK could be obtained.
        #[arg(long)]
        save: bool,
    },
    /// Enroll a device through a built-in provider.
    EnrollDevice {
        /// Enrollment provider id. See `profiles`.
        #[arg(long, default_value = "apple-watch")]
        provider: String,
        /// Bluetooth adapter name. Uses the `BlueZ` default adapter when omitted.
        #[arg(long)]
        adapter: Option<String>,
        /// Seconds to wait for the device to complete enrollment.
        #[arg(long, default_value_t = 300)]
        timeout_secs: u64,
        /// Device id to write when --save is given. Defaults to the name the
        /// device reports for itself.
        #[arg(long)]
        id: Option<String>,
        /// Save the resulting credentials. Off by default.
        #[arg(long)]
        save: bool,
    },
    /// List device profiles and their enrollment providers.
    Profiles,
    /// Show what `BlueZ` recorded for each bonded device, including whether the
    /// peer distributed an IRK. Needs root to read the bond records.
    BondInfo {
        /// Bluetooth adapter name. Uses the `BlueZ` default adapter when omitted.
        #[arg(long)]
        adapter: Option<String>,
        /// Print key material, including the IRK. Off by default.
        #[arg(long)]
        show_keys: bool,
    },
    /// Internal privileged listener for kernel IRK events.
    #[command(hide = true)]
    MgmtMonitor {
        #[arg(long)]
        adapter_index: u16,
    },
    /// Check configuration, the daemon socket, and the lock-screen integration.
    Doctor,
    /// Print the daemon's per-device and aggregate decision.
    Status,
    /// Apply the lock-screen integration for this user: the Omarchy shell
    /// plugin, the Alt binding, and the presence service. Unprivileged, and
    /// safe to rerun after an Omarchy or package update.
    Setup,
    /// Remove the lock-screen integration, the binding, the PAM policy, and
    /// the presence service. Installed files under /usr are reported rather
    /// than deleted: they are root-owned and a package may own them.
    Uninstall {
        /// Also delete the enrolled devices and their keys.
        #[arg(long)]
        forget_devices: bool,
    },
    /// Interactive menu: enroll a device, manage enrolled devices, configure
    /// multi-device authentication, run diagnostics, and watch live status.
    /// Also runs when no subcommand is given, in a terminal.
    Init,
}

/// Prints what an enrollment reports as it happens.
///
/// Enrollments never print for themselves — the interactive menu repaints a
/// live checklist from the same events — so this is what makes the
/// non-interactive command say anything at all while it waits.
fn report_progress(progress: enrollment::Progress) {
    match progress {
        enrollment::Progress::Phase(phase) => println!("{}", phase.describe()),
        enrollment::Progress::Enrolled { id, .. } => {
            println!("enrolled as {id}; restart presenced");
        }
        enrollment::Progress::Cleanup(cleanup) if cleanup.ok => {
            println!("{}", cleanup.label);
        }
        enrollment::Progress::Cleanup(cleanup) => {
            eprintln!("warning: could not complete cleanup: {}", cleanup.label);
        }
    }
}

/// Runs one guided enrollment non-interactively.
///
/// No key reader here, so Ctrl+C is the only way out and quitting and
/// cancelling are the same thing: the flag unwinds enrollment so the adapter
/// stops being pairable, and a second Ctrl+C gives up on that and exits.
fn enroll_device(
    provider: &str,
    adapter: Option<&str>,
    timeout_secs: u64,
    id: Option<&str>,
    save: bool,
) -> Result<(), String> {
    interrupt::install(|| {});
    println!("Press Ctrl+C to stop waiting.");
    enrollment::enroll(
        provider,
        &enrollment::Request {
            adapter,
            timeout_secs,
            id,
            save,
            cancel: &interrupt::QUIT_REQUESTED,
            progress: &report_progress,
        },
    )?;
    // The enrolled id is reported as it is written, because only the flow
    // knows what the device called itself.
    if !save {
        println!("identity obtained and verified; re-run with --save to enroll it");
    }
    Ok(())
}

fn enroll(id: &str) -> Result<(), String> {
    let irk = rpassword::prompt_password("Paste the macOS Remote IRK (base64): ")
        .map_err(|error| error.to_string())?;
    devices::add(
        id,
        "apple-continuity",
        &Criteria {
            irk_base64: Some(irk.trim().to_string()),
            ..Criteria::default()
        },
        &Overrides {
            threshold_dbm: None,
            minimum_samples: None,
            freshness_ms: None,
        },
    )?;
    println!("Enrolled {id}. Start with: systemctl --user enable --now presenced");
    Ok(())
}

fn status() -> Result<(), String> {
    // Informational: any well-formed reply is a success, denial included.
    for line in client::request_lines(wire::REQ_STATUS, Duration::from_millis(200))? {
        println!("{line}");
    }
    Ok(())
}

/// Removes the integration and the service, reporting each step as it goes.
///
/// Every step is attempted whatever the ones before it did, so a single
/// failure — a declined sudo prompt, say — cannot strand the rest.
fn uninstall(forget_devices: bool) -> Result<(), String> {
    let steps = setup::uninstall(if forget_devices {
        setup::Enrollment::Forget
    } else {
        setup::Enrollment::Keep
    });
    let mut failed = 0;
    for step in &steps {
        match &step.detail {
            None => println!("ok: {}", step.label),
            Some(detail) => {
                failed += 1;
                eprintln!("failed: {} — {detail}", step.label);
            }
        }
    }
    let remaining = setup::remaining_system_files();
    if !remaining.is_empty() {
        if setup::packaged() {
            println!("remove the package to finish: pacman -Rns omarchy-presence-unlock");
        } else {
            println!("finish by hand: sudo rm -rf {}", remaining.join(" "));
        }
    }
    if failed == 0 {
        Ok(())
    } else {
        Err(format!("{failed} removal step(s) did not complete"))
    }
}

fn main() {
    let Cli { command } = Cli::parse();
    let result = match command {
        None if std::io::stdin().is_terminal() => wizard::run(),
        None => {
            let _ = Cli::command().print_help();
            println!();
            Ok(())
        }
        Some(Commands::Enroll { id }) => enroll(&id),
        Some(Commands::AddDevice {
            id,
            profile,
            address,
            irk,
            service_uuid,
            name_prefix,
            threshold_dbm,
            minimum_samples,
            freshness_ms,
        }) => devices::add(
            &id,
            &profile,
            &Criteria {
                irk_base64: irk,
                address,
                service_uuid,
                name_prefix,
            },
            &Overrides {
                threshold_dbm,
                minimum_samples,
                freshness_ms,
            },
        ),
        Some(Commands::RemoveDevice { id }) => devices::remove(&id),
        Some(Commands::MultiDeviceAuth { expression }) => {
            devices::set_multi_device_auth(&expression)
        }
        Some(Commands::Devices { adapter, scan_secs }) => {
            pairing::list_advertising(adapter.as_deref(), scan_secs)
        }
        Some(Commands::Pair {
            adapter,
            scan_secs,
            id,
            save,
        }) => pairing::pair(adapter.as_deref(), scan_secs, &id, save),
        Some(Commands::EnrollDevice {
            provider,
            adapter,
            timeout_secs,
            id,
            save,
        }) => enroll_device(
            &provider,
            adapter.as_deref(),
            timeout_secs,
            id.as_deref(),
            save,
        ),
        Some(Commands::Profiles) => {
            enrollment::print_catalog();
            Ok(())
        }
        Some(Commands::BondInfo { adapter, show_keys }) => {
            pairing::bond_info(adapter.as_deref(), show_keys)
        }
        Some(Commands::MgmtMonitor { adapter_index }) => enrollment::run_mgmt_helper(adapter_index),
        Some(Commands::Doctor) => doctor::doctor(),
        Some(Commands::Status) => status(),
        Some(Commands::Setup) => setup::apply(),
        Some(Commands::Uninstall { forget_devices }) => uninstall(forget_devices),
        Some(Commands::Init) => wizard::run(),
    };
    if let Err(error) = result {
        eprintln!("error: {error}");
        std::process::exit(1);
    }
    // The menu returns normally when Ctrl+C asked it to leave, so that its
    // destructors run; the conventional status is applied here instead.
    if interrupt::quit_requested() {
        std::process::exit(130);
    }
}
